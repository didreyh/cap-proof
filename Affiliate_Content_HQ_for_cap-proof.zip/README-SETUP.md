# Affiliate Content HQ (existing cap-proof GitHub Pages site)

This is a replacement for the original Tatak JPD AWB recording web app.
It keeps the existing `firebase.js` configuration and Firebase email/password login.

## What's included

- `index.html` — new Affiliate Content HQ: 83 affiliate products, four TikTok accounts with 4 videos each per day, TikTok/Shopee/FB Page 1 upload checkboxes, missed uploads, product rotation, and FB Page 2 couple-rides tracker.
- `login.html` — original Firebase login flow, renamed for the planner.
- `firebase.js` — original Firebase project settings (unchanged).
- `cleanup-awb.html` — OPTIONAL one-time cleanup tool for the old Firestore `packingLogs` collection. It requires existing Firebase login and DELETE confirmation. Download AWB backup before deleting. It does not affect new `affiliateHQ` data.

## Deploy to the EXISTING repository

1. Keep a copy of your original GitHub repository ZIP as backup.
2. Open https://github.com/didreyh/cap-proof and select **Add file → Upload files**.
3. Upload the files from this unzipped folder to the ROOT of the repository (not inside another folder). Replace the existing `index.html`, `login.html`, and `firebase.js` when prompted. Upload the new `cleanup-awb.html` too.
4. Commit changes and open https://didreyh.github.io/cap-proof/index.html. The GitHub Pages site usually rebuilds after committing.
5. Login with your OLD account.

**Important:** GitHub Pages publishes *static files*, not the Firestore data. The old AWB records will still be in Firebase until manually deleted. Do NOT assume deleting the GitHub AWB code deletes those cloud records.

## Firestore security rules

The new app uses:
- `affiliateHQ/{userUID}/data/profile` for products and FB Page 2 travel data.
- `affiliateHQ/{userUID}/days/{YYYY-MM-DD}` for daily assignments and checkboxes.

Firestore security rules MUST permit the logged-in user's UID to access only their own affiliateHQ documents. If current rules do not already do so, add a **specific** rule inside your existing `match /databases/{database}/documents` block (do not replace your other existing rules blindly):

```
match /affiliateHQ/{userId}/{document=**} {
  allow read, write: if request.auth != null && request.auth.uid == userId;
}
```

Without that rule, the website shows a prominent **Offline: local only** warning and uses a browser-only fallback. Never set broad public Firestore read/write permissions.

## Deleting the OLD records

Once the new site has been uploaded, open:
https://didreyh.github.io/cap-proof/cleanup-awb.html

1. Sign in when prompted.
2. Download AWB JSON backup.
3. Type DELETE, then press **Delete all AWB records**, and confirm.
4. If deletion fails due to permission rules, use Firebase Console → Firestore Database → Data → `packingLogs` and delete the collection there under your administrator account.
5. After cleanup, optionally delete `cleanup-awb.html` from GitHub to remove the cleanup tool.

The AFFILIATE data is saved in `affiliateHQ` separately, not `packingLogs`.

## Local import and sync

- On the first login, existing local data from the previous Affiliate Content HQ HTML version can be imported automatically if it was used in the same browser origin, or use **Restore** with your JSON backup.
- Changes are saved in Firestore shortly after you edit a checkbox or assignment. Another device loads cloud data when you open/refresh the page. It is not a live collaborative editor; avoid keeping the same day's form open and actively editing on multiple devices at the same time.
- Use **Backup** periodically for extra safety.
